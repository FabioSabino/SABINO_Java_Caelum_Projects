package br.com.caelum.contas.ui;

import br.com.caelum.contas.modelo.*;
import br.com.caelum.javafx.api.util.Evento;


public class ManipuladorDeContas {
	private Conta c;
	public void criaConta(Evento evento) {
		c = new Conta();

		String tipo = evento.getSelecionadoNoRadio("tipo");
		if (tipo.equals("Conta Corrente")) {
			this.c = new ContaCorrente();
		}else if (tipo.equals("Conta Poupanca")) {
			this.c = new ContaPoupanca();
		}
		c.setAgencia(evento.getInt("agencia"));
		c.setNumero(evento.getInt("numero"));
		c.setTitular(evento.getString("titular"));
	}
	
}