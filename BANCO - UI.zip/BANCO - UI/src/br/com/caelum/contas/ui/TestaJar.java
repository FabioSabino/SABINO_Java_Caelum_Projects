package br.com.caelum.contas.ui;

import br.com.caelum.javafx.api.main.TelaDeContas;

public class TestaJar {

	public static void main(String[] args) {
		TelaDeContas.main(args);
		//OlaMundo.main(args);

	}

}
