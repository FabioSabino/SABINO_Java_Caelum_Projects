package br.com.caelum.contas;
public class Conta {

// Criando os atributos
	public String agencia;
	public int numero;
	public String titular;
	public double saldo;
	private double limite;
	private static int totalDeContas;
	private static int identificador;

//Construtor da Classe
	public Conta(String titular) {
		this.titular = titular;
		Conta.totalDeContas += 1;
		Conta.identificador += 1;
	}
	
	public Conta() {
		Conta.totalDeContas += 1;
		Conta.identificador += 1;
        }

// Criando os Métodos
	public boolean saca(double valor) {
		if (this.saldo < valor) {
			System.out.println("Valor Insuficiente para saque!!");
			return false;
		}
		else {
			this.saldo = this.saldo - valor;
			System.out.println("Saque Efetado com sucesso!!");
			return true;
		}
	}

	public double getSaldo() {
		return this.saldo + this.getLimite();
	}
	
	 public void deposita(double valor) {
		this.saldo += valor;
	}

	public String getTitular() {
		return this.titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public int getTotalDeContas () {
		return Conta.totalDeContas;
	}

	public int getIdentificador () {
		return Conta.identificador;
	}
	
	public boolean transfere(Conta destino, double valor) {
		if (this.saca(valor)) {
			destino.deposita(valor);
			System.out.println("Transferência Realizada com suscesso para " + destino.titular);
			return true;
		}
		else {
			System.out.println("Transferência não efetuada!");
			return false;
		}
	}

	double calculaRendimento() {
		double rendimento = (this.saldo + (this.saldo * 0.1));
		this.saldo = rendimento;
		return rendimento;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public double getLimite() {
		return limite;
	}

	public void setLimite(double limite) {
		this.limite += limite;
	}

	
}
