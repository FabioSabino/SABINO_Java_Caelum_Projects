package br.com.caelum.contas.main;
import br.com.caelum.contas.Conta;
import br.com.caelum.contas.modelo.*;

public class TestaConta {
	public static void main(String[] args) {

		// Criando uma referência para o objeto 	
		Conta account  = new Conta("Fabio");	
		Conta account2 = new Conta();

		// Alterando os valores do objeto criado
			account.numero  = 123;
			account.setTitular("Fabio");
			account.deposita(2000.0);
			int totalAccounts = account.getTotalDeContas();
			
			account2.setNumero(321);
			account2.setTitular("Priscila");
			account2.deposita(0.0);
			account2.setLimite(0.0);


		//Invocando métodos
			account.saca(500);
			//account.deposita(2501);
			//account.transfere(account2,300.0);
			//account.calculaRendimento();

		// Imprimindo os valores atribuidos ao objeto (através da ref "account")
			//System.out.println("Valor Depositado para: " + account2.titular + " foi: " + account2.saldo);
			//System.out.println("Saldo de: "+ account.titular + " é "  + account.saldo);
			//System.out.println(account.titular);	
			System.out.println("Titular da Conta: " + account.getTitular() + " ==> Saldo da Conta: " + account.getSaldo());	
			System.out.println("O Total de Contas atual é: " + totalAccounts);	

		}
		}