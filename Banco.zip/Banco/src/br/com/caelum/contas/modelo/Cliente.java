package br.com.caelum.contas.modelo;

public class Cliente {
	//private Conta conta;
	public void mostra() {
		//conta = new Conta();
		//conta.setSaldo(200.0);
	}

}
