package br.com.caelum.contas.modelo;

import br.com.caelum.contas.Conta;

public class ContaCorrente extends Conta {
	public String getTipo() {
		return "Conta Corrente";
	}

}
