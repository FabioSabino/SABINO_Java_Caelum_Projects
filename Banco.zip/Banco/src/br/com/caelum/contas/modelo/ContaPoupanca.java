package br.com.caelum.contas.modelo;

import br.com.caelum.contas.Conta;

public class ContaPoupanca extends Conta {
	public String getTipo() {
		return "Conta Poupanca";
	}

}
