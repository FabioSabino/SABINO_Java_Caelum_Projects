package br.com.caelum.contas;

import br.com.caelum.contas.modelo.Conta;

public class ContaPoupanca extends Conta {
	/**public String getTipo() {
		return "Conta Poupanca";
	}**/

}
