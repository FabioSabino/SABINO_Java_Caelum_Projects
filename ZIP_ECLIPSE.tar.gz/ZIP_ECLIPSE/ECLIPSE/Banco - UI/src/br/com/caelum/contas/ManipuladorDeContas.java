package br.com.caelum.contas;

import br.com.caelum.contas.modelo.Conta;
import br.com.caelum.javafx.api.util.Evento;

public class ManipuladorDeContas {
	private Conta c;
	public void criaConta(Evento evento) {
		c = new Conta();
		/**
		c.setAgencia(1234);
		c.setNumero(543);
		c.setTitular("Sabino");
		c.setSaldo(200.0);
		**/
// Exercicio 9.7
// Mapenado o tipo de Conta
		String tipo = evento.getSelecionadoNoRadio("tipo");
		if (tipo.equals("Conta Corrente")) {
			this.c = new ContaCorrente();
		}else if (tipo.equals("Conta Poupanca")) {
			this.c = new ContaPoupanca();
		}
		c.setAgencia(evento.getInt("agencia"));
		c.setNumero(evento.getInt("numero"));
		c.setTitular(evento.getString("titular"));
	}
	
}
