package br.com.caelum.contas.ui;

import br.com.caelum.javafx.api.main.SistemaBancario;

public class TestaContaUI {

	public static void main(String[] args) {
		//OlaMundo.main(args);
		//TelaDeContas.main(args);
		SistemaBancario.mostraTela(false);

	}

}
