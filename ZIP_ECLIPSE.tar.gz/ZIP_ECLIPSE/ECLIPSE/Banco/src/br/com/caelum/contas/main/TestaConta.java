package br.com.caelum.contas.main;
import br.com.caelum.contas.modelo.*;

public class TestaConta {
	public static void main(String[] args) {
		Conta c1 = new Conta();
		c1.setSaldo(100.0);

		System.out.println("Seu saldo é: " + c1.getSaldo());
	}

	//

	//

}
