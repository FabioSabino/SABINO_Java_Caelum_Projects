package br.com.caelum.contas.modelo;
public class Conta {

// Criando os atributos
	private int agencia;
	private int numero;
	private String titular;
	private double saldo;
	private double limite;
	private static int totalDeContas;
	private static int identificador;

//Construtor da Classe
	Conta(String titular) {
		this.titular = titular;
		Conta.totalDeContas += 1;
		Conta.identificador += 1;
	}
	
	public Conta() {
		Conta.totalDeContas += 1;
		Conta.identificador += 1;
        }

// Criando os Métodos
	public boolean saca(double valor) {
		if (this.saldo < valor) {
			System.out.println("Valor Insuficiente para saque!!");
			return false;
		}
		else {
			this.saldo = this.saldo - valor;
			System.out.println("Saque Efetado com sucesso!!");
			return true;
		}
	}

	public double getSaldo() {
		return this.saldo + this.limite;
	}

	// public void deposita(double valor) { Alterado para getters and setters
	public void setSaldo(double valor) {
		this.saldo += valor;
	}

	public String getTitular() {
		return this.titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public int getTotalDeContas () {
		return Conta.totalDeContas;
	}

	public int getIdentificador () {
		return Conta.identificador;
	}
	
	public boolean transfere(Conta destino, double valor) {
		if (this.saca(valor)) {
			destino.setSaldo(valor);
			this.saldo = (this.saldo - valor);
			System.out.println("Transferência Realizada com suscesso para " + destino.titular);
			return true;
		}
		else {
			System.out.println("Transferência não efetuada!");
			return false;
		}
	}

	double calculaRendimento() {
		double rendimento = (this.saldo + (this.saldo * 0.1));
		this.saldo = rendimento;
		return rendimento;
	}

	public int getAgencia() {
		return agencia;
	}

	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	
}
