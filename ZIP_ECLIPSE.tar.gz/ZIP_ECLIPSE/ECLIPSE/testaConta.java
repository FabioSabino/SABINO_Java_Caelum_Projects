class testaConta {

public static void main(String[] args) {

// Criando uma referência para o objeto 	
Conta account  = new Conta("Fabio");	
Conta account2 = new Conta();
PessoaFisica voce = new PessoaFisica("52352-9532");

// Testando Composição
	//account.titular = cli.nome;

// Alterando os valores do objeto criado
	account.numero  = 123;
	//account.setTitular("Fabio");
	account.setSaldo(2000.0);
	int totalAccounts = account.getTotalDeContas();
	
//	account2.numero    = 321;
//	account2.titular   = "Priscila";
//	account2.deposita  = 0.0;
//	account2.limite    = 0.0;


//Invocando métodos
	account.saca(500);
	//account.deposita(2501);
	//account.transfere(account2,300.0);
	//account.calculaRendimento();

// Imprimindo os valores atribuidos ao objeto (através da ref "account")
	//System.out.println("Valor Depositado para: " + account2.titular + " foi: " + account2.saldo);
	//System.out.println("Saldo de: "+ account.titular + " é "  + account.saldo);
	//System.out.println(account.titular);	
	System.out.println("Titular da Conta: " + account.getTitular() + " ==> Saldo da Conta: " + account.getSaldo());	
	System.out.println("O Total de Contas atual é: " + totalAccounts);	

}
}
